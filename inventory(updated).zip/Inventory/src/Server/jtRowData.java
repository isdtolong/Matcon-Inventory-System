/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import inventory.*;

/**
 *
 * @author HDJ_Dev
 */
class jtRowData {
    
}
